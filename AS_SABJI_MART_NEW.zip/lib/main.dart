import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp();

  await FirebaseAuth.instance.signInAnonymously();

  runApp(const ASSabjiMartApp());
}

const green = Color(0xFF397143);
const lightGreen = Color(0xFFE7F5E8);

class ASSabjiMartApp extends StatelessWidget {
  const ASSabjiMartApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AS Sabji Mart',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: green),
        scaffoldBackgroundColor: const Color(0xFFF7FBF4),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class Product {
  final String hindi;
  final String english;
  final String emoji;
  final String category;
  double quantity;

  Product({
    required this.hindi,
    required this.english,
    required this.emoji,
    required this.category,
    this.quantity = 0,
  });
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final searchController = TextEditingController();
  String selectedCategory = 'सब्जियाँ';
  String searchText = '';

  final List<Product> products = [
    Product(hindi:'आलू',english:'Potato',emoji:'🥔',category:'सब्जियाँ'),
    Product(hindi:'प्याज',english:'Onion',emoji:'🧅',category:'सब्जियाँ'),
    Product(hindi:'टमाटर',english:'Tomato',emoji:'🍅',category:'सब्जियाँ'),
    Product(hindi:'हरी मिर्च',english:'Green Chilli',emoji:'🌶️',category:'सब्जियाँ'),
    Product(hindi:'अदरक',english:'Ginger',emoji:'🫚',category:'सब्जियाँ'),
    Product(hindi:'लहसुन',english:'Garlic',emoji:'🧄',category:'सब्जियाँ'),
    Product(hindi:'गाजर',english:'Carrot',emoji:'🥕',category:'सब्जियाँ'),
    Product(hindi:'भिंडी',english:'Okra',emoji:'🥬',category:'सब्जियाँ'),
    Product(hindi:'बैंगन',english:'Brinjal',emoji:'🍆',category:'सब्जियाँ'),
    Product(hindi:'करेला',english:'Bitter Gourd',emoji:'🥒',category:'सब्जियाँ'),
    Product(hindi:'खीरा',english:'Cucumber',emoji:'🥒',category:'सब्जियाँ'),
    Product(hindi:'फ्रेंच बीन्स',english:'French Beans',emoji:'🫛',category:'सब्जियाँ'),
    Product(hindi:'मटर',english:'Green Peas',emoji:'🫛',category:'सब्जियाँ'),
    Product(hindi:'फूलगोभी',english:'Cauliflower',emoji:'🥦',category:'सब्जियाँ'),
    Product(hindi:'पत्तागोभी',english:'Cabbage',emoji:'🥬',category:'सब्जियाँ'),
    Product(hindi:'शिमला मिर्च',english:'Capsicum',emoji:'🫑',category:'सब्जियाँ'),
    Product(hindi:'धनिया',english:'Coriander',emoji:'🌿',category:'सब्जियाँ'),
    Product(hindi:'पुदीना',english:'Mint',emoji:'🌿',category:'सब्जियाँ'),
    Product(hindi:'पालक',english:'Spinach',emoji:'🥬',category:'सब्जियाँ'),
    Product(hindi:'चौलाई',english:'Amaranth',emoji:'🌿',category:'सब्जियाँ'),
    Product(hindi:'मेथी',english:'Fenugreek',emoji:'🌿',category:'सब्जियाँ'),
    Product(hindi:'सोआ',english:'Dill Leaves',emoji:'🌿',category:'सब्जियाँ'),
    Product(hindi:'हरा प्याज',english:'Spring Onion',emoji:'🌱',category:'सब्जियाँ'),
    Product(hindi:'मूली',english:'Radish',emoji:'🥗',category:'सब्जियाँ'),
    Product(hindi:'शलजम',english:'Turnip',emoji:'🥗',category:'सब्जियाँ'),
    Product(hindi:'चुकंदर',english:'Beetroot',emoji:'🟣',category:'सब्जियाँ'),
    Product(hindi:'शकरकंद',english:'Sweet Potato',emoji:'🍠',category:'सब्जियाँ'),
    Product(hindi:'अरबी',english:'Taro',emoji:'🥔',category:'सब्जियाँ'),
    Product(hindi:'कद्दू',english:'Pumpkin',emoji:'🎃',category:'सब्जियाँ'),
    Product(hindi:'परवल',english:'Pointed Gourd',emoji:'🥒',category:'सब्जियाँ'),
    Product(hindi:'कुंदरू',english:'Ivy Gourd',emoji:'🥒',category:'सब्जियाँ'),
    Product(hindi:'लौकी',english:'Bottle Gourd',emoji:'🥒',category:'सब्जियाँ'),
    Product(hindi:'तुरई',english:'Ridge Gourd',emoji:'🥒',category:'सब्जियाँ'),
    Product(hindi:'सहजन',english:'Drumstick',emoji:'🌿',category:'सब्जियाँ'),
    Product(hindi:'मक्का',english:'Corn',emoji:'🌽',category:'सब्जियाँ'),
    Product(hindi:'मशरूम',english:'Mushroom',emoji:'🍄',category:'सब्जियाँ'),
    Product(hindi:'नींबू',english:'Lemon',emoji:'🍋',category:'सब्जियाँ'),
    Product(hindi:'करी पत्ता',english:'Curry Leaves',emoji:'🌿',category:'सब्जियाँ'),

    Product(hindi:'सेब',english:'Apple',emoji:'🍎',category:'फल'),
    Product(hindi:'केला',english:'Banana',emoji:'🍌',category:'फल'),
    Product(hindi:'आम',english:'Mango',emoji:'🥭',category:'फल'),
    Product(hindi:'अंगूर',english:'Grapes',emoji:'🍇',category:'फल'),
    Product(hindi:'संतरा',english:'Orange',emoji:'🍊',category:'फल'),
    Product(hindi:'अनार',english:'Pomegranate',emoji:'🍎',category:'फल'),
    Product(hindi:'अमरूद',english:'Guava',emoji:'🍐',category:'फल'),
    Product(hindi:'पपीता',english:'Papaya',emoji:'🍈',category:'फल'),
    Product(hindi:'तरबूज',english:'Watermelon',emoji:'🍉',category:'फल'),
    Product(hindi:'खरबूजा',english:'Muskmelon',emoji:'🍈',category:'फल'),
    Product(hindi:'अनानास',english:'Pineapple',emoji:'🍍',category:'फल'),
    Product(hindi:'नाशपाती',english:'Pear',emoji:'🍐',category:'फल'),
    Product(hindi:'आड़ू',english:'Peach',emoji:'🍑',category:'फल'),
    Product(hindi:'चेरी',english:'Cherry',emoji:'🍒',category:'फल'),
    Product(hindi:'स्ट्रॉबेरी',english:'Strawberry',emoji:'🍓',category:'फल'),
    Product(hindi:'कीवी',english:'Kiwi',emoji:'🥝',category:'फल'),
    Product(hindi:'नारियल',english:'Coconut',emoji:'🥥',category:'फल'),
    Product(hindi:'लीची',english:'Lychee',emoji:'🍒',category:'फल'),
    Product(hindi:'जामुन',english:'Jamun',emoji:'🫐',category:'फल'),
    Product(hindi:'चीकू',english:'Sapota',emoji:'🍐',category:'फल'),
    Product(hindi:'सीताफल',english:'Custard Apple',emoji:'🍈',category:'फल'),
    Product(hindi:'ड्रैगन फ्रूट',english:'Dragon Fruit',emoji:'🍉',category:'फल'),
    Product(hindi:'ब्लूबेरी',english:'Blueberry',emoji:'🫐',category:'फल'),
    Product(hindi:'खजूर',english:'Dates',emoji:'🌴',category:'फल'),
    Product(hindi:'आंवला',english:'Amla',emoji:'🟢',category:'फल'),
  ];

  double get totalWeight =>
      products.fold(0, (sum, item) => sum + item.quantity);

  List<Product> get cartItems =>
      products.where((item) => item.quantity > 0).toList();

  int get deliveryCharge {
    if (totalWeight <= 0 || totalWeight > 10) return 0;
    return totalWeight <= 5 ? 10 : 20;
  }

  List<Product> get visibleProducts {
    return products.where((item) {
      return item.category == selectedCategory &&
          (item.hindi.contains(searchText) ||
              item.english.toLowerCase().contains(
                searchText.toLowerCase(),
              ));
    }).toList();
  }

  String formatWeight(double weight) {
    if (weight < 1) return '${(weight * 1000).round()} ग्राम';
    return '${weight.toStringAsFixed(3).replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '')} किलो';
  }

  void changeQuantity(Product product, double amount) {
    setState(() {
      product.quantity =
          double.parse((product.quantity + amount).toStringAsFixed(3));
      if (product.quantity < 0.001) product.quantity = 0;
    });
  }

  void addProduct(Product product) {
    showDialog(
      context: context,
      builder: (dialogContext) {
        double selectedQuantity = 0.25;

        return StatefulBuilder(
          builder: (context, setDialogState) {
            final options = <double>[0.25, 0.5, 0.75, 1.0];

            return AlertDialog(
              title: Text('${product.hindi} (${product.english})'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(product.emoji, style: const TextStyle(fontSize: 48)),
                  const SizedBox(height: 12),
                  for (final quantity in options)
                    Container(
                      width: double.infinity,
                      margin: const EdgeInsets.only(bottom: 8),
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          backgroundColor: selectedQuantity == quantity
                              ? green
                              : Colors.white,
                          foregroundColor: selectedQuantity == quantity
                              ? Colors.white
                              : green,
                          side: const BorderSide(color: green),
                        ),
                        onPressed: () {
                          setDialogState(() {
                            selectedQuantity = quantity;
                          });
                        },
                        child: Text(
                          quantity < 1
                              ? '${(quantity * 1000).round()} g'
                              : '${quantity.toStringAsFixed(0)} kg',
                        ),
                      ),
                    ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('रद्द करें'),
                ),
                FilledButton(
                  onPressed: () {
                    changeQuantity(product, selectedQuantity);
                    Navigator.pop(dialogContext);
                    ScaffoldMessenger.of(this.context).showSnackBar(
                      SnackBar(
                        content: Text('${product.hindi} कार्ट में जुड़ गया।'),
                      ),
                    );
                  },
                  child: const Text('Add to Cart'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void showCart() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return SafeArea(
              child: SizedBox(
                height: MediaQuery.of(context).size.height * 0.82,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'आपका कार्ट',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text('कुल वजन: ${formatWeight(totalWeight)}'),
                      Text('डिलीवरी चार्ज: ₹$deliveryCharge'),
                      const Divider(),
                      Expanded(
                        child: cartItems.isEmpty
                            ? const Center(child: Text('कार्ट खाली है।'))
                            : ListView.builder(
                                itemCount: cartItems.length,
                                itemBuilder: (context, index) {
                                  final item = cartItems[index];
                                  return ListTile(
                                    leading: Text(
                                      item.emoji,
                                      style: const TextStyle(fontSize: 30),
                                    ),
                                    title: Text(item.hindi),
                                    subtitle: Text(formatWeight(item.quantity)),
                                    trailing: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        IconButton(
                                          onPressed: () {
                                            changeQuantity(item, -0.25);
                                            setSheetState(() {});
                                          },
                                          icon: const Icon(
                                            Icons.remove_circle_outline,
                                          ),
                                        ),
                                        IconButton(
                                          onPressed: () {
                                            changeQuantity(item, 0.25);
                                            setSheetState(() {});
                                          },
                                          icon: const Icon(
                                            Icons.add_circle_outline,
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                      ),
                      if (totalWeight > 10)
                        const Text(
                          '10 किलो से अधिक का ऑर्डर स्वीकार नहीं है।',
                          style: TextStyle(color: Colors.red),
                        ),
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton(
                          onPressed: cartItems.isEmpty || totalWeight > 10
                              ? null
                              : () {
                                  Navigator.pop(sheetContext);
                                  showOrderForm();
                                },
                          child: const Text('ऑर्डर आगे बढ़ाएँ'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  void showOrderForm() {
    final formKey = GlobalKey<FormState>();
    final name = TextEditingController();
    final phone = TextEditingController();
    final society = TextEditingController();
    final building = TextEditingController();
    final flat = TextEditingController();
    final area = TextEditingController();
    final city = TextEditingController();
    final pin = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) {
        return Padding(
          padding: EdgeInsets.only(
            left: 18,
            right: 18,
            top: 18,
            bottom: MediaQuery.of(sheetContext).viewInsets.bottom + 18,
          ),
          child: SizedBox(
            height: MediaQuery.of(sheetContext).size.height * 0.85,
            child: Form(
              key: formKey,
              child: ListView(
                children: [
                  const Text(
                    'ग्राहक का पता',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text('कुल वजन: ${formatWeight(totalWeight)}'),
                  Text('डिलीवरी चार्ज: ₹$deliveryCharge'),
                  const SizedBox(height: 12),
                  addressField(name, 'ग्राहक का नाम'),
                  addressField(
                    phone,
                    'मोबाइल नंबर',
                    keyboardType: TextInputType.phone,
                    validator: (value) {
                      if (value == null || !RegExp(r'^[0-9]{10}$').hasMatch(value)) {
                        return '10 अंकों का मोबाइल नंबर लिखें';
                      }
                      return null;
                    },
                  ),
                  addressField(society, 'सोसाइटी का नाम'),
                  addressField(building, 'बिल्डिंग का नाम'),
                  addressField(flat, 'फ्लैट / रूम नंबर'),
                  addressField(area, 'एरिया / मोहल्ला'),
                  addressField(city, 'शहर'),
                  addressField(
                    pin,
                    'पिन कोड',
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || !RegExp(r'^[0-9]{6}$').hasMatch(value)) {
                        return '6 अंकों का पिन कोड लिखें';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),
                  const Text('डिलीवरी समय: शाम 5:00 से 7:00 बजे'),
                  const Text('सब्जियों की अंतिम कीमत बाज़ार के भाव के अनुसार होगी।'),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: () async {
                      if (!formKey.currentState!.validate()) return;

                      final orderSummary = cartItems
                          .map((item) =>
                              '${item.hindi}: ${formatWeight(item.quantity)}')
                          .join('/n');
  try {    
await FirebaseFirestore.instance.collection('orders').add({
  'customerName': name.text.trim(),
  'phone': phone.text.trim(),
  'society': society.text.trim(),
  'building': building.text.trim(),
  'flat': flat.text.trim(),
  'area': area.text.trim(),
  'city': city.text.trim(),
  'pin': pin.text.trim(),
  'orderSummary': orderSummary,
  'totalWeight': totalWeight,
  'deliveryCharge': deliveryCharge,
  'status': 'नया ऑर्डर',
  'createdAt': FieldValue.serverTimestamp(),
});
  } catch (e) {
  ScaffoldMessenger.of(this.context).showSnackBar(
    SnackBar(content: Text('ऑर्डर सेव नहीं हुआ: $e')),
  );
  return;
}              Navigator.pop(sheetContext);

                      showDialog(
                        context: this.context,
                        builder: (dialogContext) => AlertDialog(
                          title: const Text('ऑर्डर विवरण तैयार'),
                          content: SingleChildScrollView(
                            child: Text(
                              'ग्राहक: ${name.text}\n'
                              'मोबाइल: ${phone.text}\n'
                              'पता: ${society.text}, ${building.text}, '
                              '${flat.text}, ${area.text}, ${city.text} - ${pin.text}\n\n'
                              '$orderSummary\n\n'
                              'कुल वजन: ${formatWeight(totalWeight)}\n'
                              'डिलीवरी चार्ज: ₹$deliveryCharge\n'
                              'डिलीवरी: शाम 5:00–7:00 बजे\n\n'
                              'यह विवरण तैयार हुआ है। Firebase सेटअप पूरा होने के बाद '
                              'इसे ऑनलाइन ऑर्डर के रूप में सेव किया जा सकेगा.',
                            ),
                          ),
                          actions: [
                            FilledButton(
                              onPressed: () => Navigator.pop(dialogContext),
                              child: const Text('ठीक है'),
                            ),
                          ],
                        ),
                      );
                    },
                    child: const Text('ऑर्डर कन्फर्म करें'),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget addressField(
    TextEditingController controller,
    String label, {
    TextInputType keyboardType = TextInputType.text,
    String? Function(String?)? validator,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        validator: validator ??
            (value) =>
                value == null || value.trim().isEmpty ? 'यह जानकारी भरें' : null,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
appBar: AppBar(
  title: Row(
    children: [
      GestureDetector(
        onTap: () {
          showAdminLogin(context);
        },
        child: Container(
          width: 42,
          height: 42,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: const Color(0xFFE8F5E9),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: green),
          ),
          child: const Text(
            'AS',
            style: TextStyle(
              color: Color(0xFF397143),
              fontSize: 19,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
      const SizedBox(width: 10),
      const Expanded(
        child: Text(
          'AS Sabji Mart',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
    ],
  ),
  actions: [
    IconButton(
      onPressed: showCart,
      icon: const Icon(Icons.shopping_cart_outlined),
    ),
    Center(
      child: Padding(
        padding: const EdgeInsets.only(right: 14),
        child: Text('${cartItems.length}'),
      ),
    ),
  ],
),

      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 6, 14, 8),
            child: TextField(
              controller: searchController,
              onChanged: (value) {
                setState(() {
                  searchText = value.trim();
                });
              },
              decoration: InputDecoration(
                hintText: 'सब्जी खोजें / Search',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: const Color(0xFFE8E9DF),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 4,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                ),
              ),
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Text(
              'अंतिम कीमत बाज़ार के भाव के अनुसार होगी।',
              style: TextStyle(color: green),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
            child: Row(
              children: [
                Expanded(child: categoryButton('सब्जियाँ')),
                const SizedBox(width: 10),
                Expanded(child: categoryButton('फल')),
              ],
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.fromLTRB(14, 4, 14, 12),
              itemCount: visibleProducts.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 0.95,
              ),
              itemBuilder: (context, index) {
                final item = visibleProducts[index];
                return Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFFF2F4EB),
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.10),
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Column(
                    children: [
                      Container(
                        height: 60,
                        width: double.infinity,
                        color: lightGreen,
                        child: Center(
                          child: Text(
                            item.emoji,
                            style: const TextStyle(fontSize: 42),
                          ),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: Text(
                          item.hindi,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      Text(
                        item.english,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 13,
                          color: Colors.black54,
                        ),
                      ),
                      const SizedBox(height: 3),
                      const Text(
                        'Market Price',
                        style: TextStyle(
                          color: green,
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                      ),
                      const Spacer(),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(8, 2, 8, 6),
                        child: SizedBox(
                          width: double.infinity,
                          height: 32,
                          child: ElevatedButton(
                            onPressed: () => addProduct(item),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: green,
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.zero,
                            ),
                            child: const Text('Add'),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget categoryButton(String title) {
    final selected = selectedCategory == title;

    return ElevatedButton(
      onPressed: () {
        setState(() {
          selectedCategory = title;
          searchController.clear();
          searchText = '';
        });
      },
      style: ElevatedButton.styleFrom(
        backgroundColor: selected ? green : Colors.white,
        foregroundColor: selected ? Colors.white : green,
        padding: const EdgeInsets.symmetric(vertical: 7),
        side: const BorderSide(color: Color(0xFFB5D5B8)),
      ),
      child: Text(title),
    );
  }
}

Future<void> showAdminLogin(BuildContext context) async {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  await showDialog(
    context: context,
    builder: (dialogContext) {
      return AlertDialog(
        title: const Text('Admin Login'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: emailController,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(
                labelText: 'Email',
              ),
            ),
            TextField(
              controller: passwordController,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: 'Password',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              try {
                await FirebaseAuth.instance.signInWithEmailAndPassword(
                  email: emailController.text.trim(),
                  password: passwordController.text,
                );

                if (dialogContext.mounted) {
                  Navigator.pop(dialogContext);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Admin login successful'),
                    ),
                  );
                }
              } on FirebaseAuthException catch (e) {
                if (dialogContext.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(e.message ?? 'Login failed')),
                  );
                }
              }
            },
            child: const Text('Login'),
          ),
        ],
      );
    },
  );

  emailController.dispose();
  passwordController.dispose();
}
